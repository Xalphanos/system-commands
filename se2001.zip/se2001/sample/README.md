Welcome to the zeroth question. This assignment is not graded and provided with a solution file as a sample.

**IMPORTANT**: execute `synchro eval` from the assignment directory (for this assignment `~/se2001/sample`) to record your submission for grading.

# Sample (Not graded)
Write a script `~/se2001/sample/script.sh` that takes a filename as argument and print only the hash value.

# Verification (Not submission)
Once you have written your script you can verify the same using the following command
```
~/se2001/sample/script.sh /opt/se2001/sample/hello.txt
```

The expected output should be
```
a948904f2f0f479b8f8197694b30184b0d2ed1c1cd2a1ec0fb85d299a192a447
```
