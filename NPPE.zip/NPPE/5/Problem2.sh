: '
Print the absolute path where the command wget is located.
'
#Solution
script() { echo '
which wget
'
}